package com.is.food.identification;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class FoodInMemDB
{
    List<String> in_mem_food_db;

    public FoodInMemDB(final String filePath)
    {
        in_mem_food_db = loadDBCSV(filePath);
    }

    public List<String> getAllFoods()
    {
        return in_mem_food_db;
    }

    private List<String> loadDBCSV(final String filePath)
    {
        List<String> foodDB = new ArrayList<>();
        try (Stream<String> lines = Files.lines(Paths.get(filePath), StandardCharsets.UTF_8)) {
            lines.forEachOrdered(line -> foodDB.add(line));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return foodDB;
    }
}
