package com.is.food.identification.simulation;

import com.is.food.identification.FoodIdentifier;
import com.is.food.identification.FoodIdentifierLeventsteinDistanceImpl;
import com.is.food.identification.FoodInMemDB;
import com.is.food.identification.GoogleSpeechToText;

import java.io.File;
import java.util.List;

public class FoodIdentificationUsingLevenstein
{

    public static void main(String args[])
    {
        String testVoicesDirPath = "/Users/selvp/src/stt/src/main/resources/test_voices/flac";
        String inMemFoodDBPath = "/Users/selvp/src/stt/src/main/resources/food_db/partialDBProcessed.txt";

        FoodInMemDB foodInMemDB = new FoodInMemDB(inMemFoodDBPath);
        FoodIdentifier foodIdentifierLevenstein = new FoodIdentifierLeventsteinDistanceImpl(foodInMemDB);
        GoogleSpeechToText speechToText = new GoogleSpeechToText();
        final File voicesFolder = new File(testVoicesDirPath);

        for (File file : voicesFolder.listFiles()) {
            System.out.println("TranscribingFile:" + file.toPath());
            List<String> transcribedTexts = speechToText.transcribeAudioFile(file);
            for (String transcribedText : transcribedTexts) {
                String foundFood = foodIdentifierLevenstein.findClosestMatch(transcribedText);
                System.out.println(String.format("TranscribedText:\t %s \t FoundFood:\t %s",
                        transcribedText, foundFood));
            }
        }
    }
}
