package com.is.food.identification;

import org.apache.commons.text.similarity.LevenshteinDistance;

public class FoodIdentifierLeventsteinDistanceImpl implements FoodIdentifier
{
    FoodInMemDB inMemDB;

    public FoodIdentifierLeventsteinDistanceImpl(FoodInMemDB foodInMemDB)
    {
        inMemDB = foodInMemDB;
    }

    @Override
    public String findClosestMatch(final String queryFood)
    {
        String foundFood = queryFood;
        Integer minDistanceSoFar = Integer.MAX_VALUE;
        for (String foodInDB : inMemDB.getAllFoods()) {
            int curMinDistance = new LevenshteinDistance().apply(queryFood, foodInDB);
            if (curMinDistance < minDistanceSoFar) {
                foundFood = foodInDB;
                minDistanceSoFar = curMinDistance;
            }
        }
        return foundFood;
    }
}
