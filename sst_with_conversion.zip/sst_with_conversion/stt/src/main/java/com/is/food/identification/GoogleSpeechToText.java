package com.is.food.identification;

import com.google.cloud.speech.v1p1beta1.RecognitionAudio;
import com.google.cloud.speech.v1p1beta1.RecognitionConfig;
import com.google.cloud.speech.v1p1beta1.RecognizeResponse;
import com.google.cloud.speech.v1p1beta1.SpeechClient;
import com.google.cloud.speech.v1p1beta1.SpeechRecognitionAlternative;
import com.google.cloud.speech.v1p1beta1.SpeechRecognitionResult;
import com.google.protobuf.ByteString;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

public class GoogleSpeechToText
{
    final SpeechClient speechClient;

    public GoogleSpeechToText()
    {
        try {
            speechClient = SpeechClient.create();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public List<String> transcribe(final ByteString audioBytes)
    {
        RecognitionAudio audio = RecognitionAudio.newBuilder()
                .setContent(audioBytes)
                .build();

        RecognitionConfig config = RecognitionConfig.newBuilder()
                .setEncoding(RecognitionConfig.AudioEncoding.FLAC)
                .setLanguageCode("en-US")
                .setSampleRateHertz(16000)
                .build();

        // Performs speech recognition on the audio file
        RecognizeResponse response = speechClient.recognize(config, audio);
        List<SpeechRecognitionResult> results = response.getResultsList();
        List<String> transcribedText = new ArrayList<>();
        for (SpeechRecognitionResult result : results) {
            // There can be several alternative transcripts for a given chunk of speech. Just use the
            // first (most likely) one here.
            SpeechRecognitionAlternative alternative = result.getAlternativesList().get(0);
            transcribedText.add(alternative.getTranscript());
        }
        return transcribedText;
    }

    public List<String> transcribeAudioFile(final File file)
    {
        try {
            byte[] data = Files.readAllBytes(file.toPath());
            return transcribe(ByteString.copyFrom(data));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
