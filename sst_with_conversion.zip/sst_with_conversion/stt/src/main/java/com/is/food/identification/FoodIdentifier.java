package com.is.food.identification;

public interface FoodIdentifier
{
    public String findClosestMatch(String queryFood);
}
