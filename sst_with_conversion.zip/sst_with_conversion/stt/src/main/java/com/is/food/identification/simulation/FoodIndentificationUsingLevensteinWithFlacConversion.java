package com.is.food.identification.simulation;

import com.google.protobuf.ByteString;
import com.is.food.identification.FoodIdentifier;
import com.is.food.identification.FoodIdentifierLeventsteinDistanceImpl;
import com.is.food.identification.FoodInMemDB;
import com.is.food.identification.GoogleSpeechToText;
import org.apache.commons.io.IOUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.HttpClientBuilder;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class FoodIndentificationUsingLevensteinWithFlacConversion
{
    public static final String FLAC_CONVERTER_SERVER_URL = "http://34.209.27.140/to_flac";
    public static void main(String args[])
    {

        HttpClient client = HttpClientBuilder.create().build();
        String testVoicesDirPath = "C:\\uci\\third quarter\\sst_with_conversion\\stt\\src\\main\\resources\\test_voices\\mp3";
        String inMemFoodDBPath = "C:\\uci\\third quarter\\sst_with_conversion\\stt\\src\\main\\resources\\food_db\\partialDBProcessed.txt";

        FoodInMemDB foodInMemDB = new FoodInMemDB(inMemFoodDBPath);
        FoodIdentifier foodIdentifierLevenstein = new FoodIdentifierLeventsteinDistanceImpl(foodInMemDB);
        GoogleSpeechToText speechToText = new GoogleSpeechToText();
        final File voicesFolder = new File(testVoicesDirPath);

        for (File file : voicesFolder.listFiles()) {
            System.out.println("Converting to required format:" + file.toPath());
            HttpPost post = new HttpPost(FLAC_CONVERTER_SERVER_URL);
            HttpEntity entity = MultipartEntityBuilder.create().addBinaryBody("data", file,
                    ContentType.create("application/octet-stream"), file.getName())
                    .build();
            post.setEntity(entity);
            ByteString convertedAudioBytes = null;
            try {
                HttpResponse response = client.execute(post);
                convertedAudioBytes = ByteString.copyFrom(IOUtils.toByteArray(response.getEntity().getContent()));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            System.out.println("TranscribingFile:" + file.toPath());
            List<String> transcribedTexts = speechToText.transcribe(convertedAudioBytes);
            for (String transcribedText : transcribedTexts) {
                String foundFood = foodIdentifierLevenstein.findClosestMatch(transcribedText);
                System.out.println(String.format("TranscribedText:\t %s \t FoundFood:\t %s",
                        transcribedText, foundFood));
            }
        }
    }
}
